
# Historial del Proyecto - Asistente Personal en Python

Desde el primer día, fuimos desarrollando un asistente personal con las siguientes características:

- Recordatorios con base de datos SQLite, ventana para agregar y ver recordatorios.
- Interfaz en Tkinter con estilo limpio usando ttkbootstrap.
- Módulo de reconocimiento de voz con Whisper de OpenAI.
- Función de clima actual y pronóstico extendido usando OpenWeatherMap.
- Soporte de comandos de voz y texto.
- Integración con modelos locales (como LLaMA3 vía Ollama).
- Módulo de memoria persistente (nombre, gustos, etc.).
- Estructura modular y escalable.
- Comando general para interactuar con modelos LLM.
