from modelo_ollama import consultar_modelo_local_ollama_stream
import configparser
import json

def interactuar_con_modelos(comando):
    from config import obtener_config
    config = obtener_config()
    modelo = config.get("modelo_ollama", "llama3")
    return consultar_modelo_local_ollama_stream(comando, modelo)