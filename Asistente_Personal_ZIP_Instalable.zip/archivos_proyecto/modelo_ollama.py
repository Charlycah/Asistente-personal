import requests
import json
import sseclient

def consultar_modelo_local_ollama_stream(prompt, modelo='llama3', stream=True):
    url = 'http://localhost:11434/api/generate'
    headers = {'Content-Type': 'application/json'}
    data = {
        'model': modelo,
        'prompt': prompt,
        'stream': stream
    }
    try:
        response = requests.post(url, headers=headers, data=json.dumps(data), stream=True)
        client = sseclient.SSEClient(response)
        for event in client.events():
            if event.data:
                parsed = json.loads(event.data)
                if 'done' in parsed and parsed['done']:
                    break
                yield parsed.get('response', '')
    except Exception as e:
        yield f"Error al conectar con el modelo local: {e}"