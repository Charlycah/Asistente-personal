import tkinter as tk
from interfaz import Interfaz
from modelo_handler import interactuar_con_modelos

if __name__ == "__main__":
    root = tk.Tk()
    app = Interfaz(root, interactuar_con_modelos)
    root.mainloop()