# Documentación Técnica - Asistente Personal en Python

## Requisitos

- Python 3.10+
- Internet para funciones de clima y modelos locales
- Modelo LLM local (como LLaMA3 vía Ollama)

## Instalación

### 1. Clona o descarga el proyecto

```
git clone https://github.com/tuusuario/asistente-personal.git
cd asistente-personal
```

O extraé el archivo ZIP y accedé al directorio.

### 2. Instala los paquetes requeridos

```
pip install -r requirements.txt
```

Asegurate de tener instalado:

- `ffmpeg` para Whisper
- `pyaudio` (en Windows puede requerir wheel: `pip install pipwin && pipwin install pyaudio`)

### 3. Ejecutá el asistente

```
python main.py
```

## Estructura del Proyecto

```
asistente_personal/
│
├── main.py
├── modelo_ollama.py
├── modelo_handler.py
├── requirements.txt
├── README.md
├── config.json
├── HISTORIAL.md
├── INSTALAR.txt
├── DOCUMENTACION_TECNICA.md
│
└── modules/
    ├── clima.py
    ├── db.py
    ├── memoria.py
    ├── ventana_recordatorio.py
    └── config.py
```

## Configuración

Editá `config.json` para cambiar la ciudad por defecto o el modelo LLM:

```json
{
  "ciudad": "Buenos Aires",
  "modelo_ollama": "llama3"
}
```

## Modelo LLM local

Este asistente usa el endpoint de Ollama corriendo localmente. Asegurate de tenerlo activo:

```
ollama run llama3
```

## Reconocimiento por voz

El sistema utiliza Whisper para transcribir la entrada de audio. También podés integrarlo con `SpeechRecognition` y `PyAudio`.

---

## Instalador

### En Windows

1. Instalá Python 3.10+ desde https://python.org
2. Asegurate de tildar “Add Python to PATH”.
3. Ejecutá `instalar.bat` o seguí `INSTALAR.txt`.

---

# Créditos

Desarrollado con ayuda de ChatGPT como copiloto inteligente.