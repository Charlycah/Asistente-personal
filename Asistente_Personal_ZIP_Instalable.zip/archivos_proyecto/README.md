# Asistente Personal con IA

Este proyecto es un asistente personal de escritorio con voz, recordatorios, clima y consulta a modelos LLM locales como LLaMA3.

## Características

- Recordatorios persistentes en SQLite
- Interfaz moderna con ttkbootstrap
- Consulta a modelos locales usando Ollama
- Clima actual y pronóstico extendido
- Memoria personalizada (gustos, nombre)
- Reconocimiento de voz con Whisper

## Requisitos

Instalá los paquetes desde `requirements.txt`:

```
pip install -r requirements.txt
```

## Ejecución

```
python main.py
```