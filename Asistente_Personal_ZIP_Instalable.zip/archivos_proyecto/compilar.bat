@echo off
echo Compilando asistente personal con PyInstaller...
pyinstaller asistente_personal.spec
pause