import requests
import json
from config import obtener_config

API_KEY = "TU_API_KEY_AQUI"

def obtener_clima_actual(ciudad):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={ciudad}&appid={API_KEY}&units=metric&lang=es"
    response = requests.get(url)
    if response.status_code == 200:
        datos = response.json()
        clima = datos['weather'][0]['description'].capitalize()
        temp = datos['main']['temp']
        return f"{clima}, {temp}°C"
    else:
        return "No se pudo obtener el clima."

def obtener_pronostico(ciudad):
    url = f"http://api.openweathermap.org/data/2.5/forecast?q={ciudad}&appid={API_KEY}&units=metric&lang=es"
    response = requests.get(url)
    if response.status_code == 200:
        datos = response.json()
        pronostico = []
        for item in datos["list"][:5]:
            clima = item["weather"][0]["description"]
            temp = item["main"]["temp"]
            hora = item["dt_txt"]
            pronostico.append(f"{hora}: {clima}, {temp}°C")
        return "\n".join(pronostico)
    else:
        return "No se pudo obtener el pronóstico."