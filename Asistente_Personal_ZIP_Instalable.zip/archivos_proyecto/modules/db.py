import sqlite3
from datetime import datetime

def conectar():
    return sqlite3.connect("recordatorios.db")

def crear_tabla():
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS recordatorios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                titulo TEXT NOT NULL,
                descripcion TEXT,
                fecha_hora TEXT NOT NULL,
                estado TEXT DEFAULT 'Pendiente'
            )
        ''')
        conn.commit()

def agregar_recordatorio(titulo, descripcion, fecha_hora):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("INSERT INTO recordatorios (titulo, descripcion, fecha_hora) VALUES (?, ?, ?)",
                       (titulo, descripcion, fecha_hora))
        conn.commit()

def obtener_proximos_recordatorios():
    with conectar() as conn:
        cursor = conn.cursor()
        ahora = datetime.now().strftime("%Y-%m-%d %H:%M")
        cursor.execute("SELECT * FROM recordatorios WHERE fecha_hora >= ? AND estado = 'Pendiente' ORDER BY fecha_hora ASC", (ahora,))
        return cursor.fetchall()

def obtener_recordatorios_vencidos():
    with conectar() as conn:
        cursor = conn.cursor()
        ahora = datetime.now().strftime("%Y-%m-%d %H:%M")
        cursor.execute("SELECT * FROM recordatorios WHERE fecha_hora < ? AND estado = 'Pendiente'", (ahora,))
        return cursor.fetchall()

def actualizar_estado_recordatorio(recordatorio_id, nuevo_estado):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE recordatorios SET estado = ? WHERE id = ?", (nuevo_estado, recordatorio_id))
        conn.commit()