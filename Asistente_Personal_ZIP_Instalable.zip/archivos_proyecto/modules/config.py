import json

def obtener_config():
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def actualizar_ciudad(ciudad):
    with open("config.json", "r+", encoding="utf-8") as f:
        data = json.load(f)
        data["ciudad"] = ciudad
        f.seek(0)
        json.dump(data, f, indent=2)
        f.truncate()