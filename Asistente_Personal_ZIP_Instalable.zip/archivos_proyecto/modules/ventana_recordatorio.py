from ttkbootstrap import Window, ttk
from modules import db

def mostrar_ventana_agregar():
    ventana = Window(themename="flatly")
    ventana.title("Agregar recordatorio")
    ventana.geometry("300x300")

    ttk.Label(ventana, text="Título").pack(pady=5)
    entry_titulo = ttk.Entry(ventana)
    entry_titulo.pack()

    ttk.Label(ventana, text="Descripción").pack(pady=5)
    entry_desc = ttk.Entry(ventana)
    entry_desc.pack()

    ttk.Label(ventana, text="Fecha y hora (YYYY-MM-DD HH:MM)").pack(pady=5)
    entry_fecha = ttk.Entry(ventana)
    entry_fecha.pack()

    def guardar():
        titulo = entry_titulo.get()
        desc = entry_desc.get()
        fecha = entry_fecha.get()
        db.agregar_recordatorio(titulo, desc, fecha)
        ventana.destroy()

    ttk.Button(ventana, text="Guardar", command=guardar).pack(pady=20)
    ventana.mainloop()