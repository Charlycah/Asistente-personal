import sqlite3

def conectar():
    return sqlite3.connect("memoria.db")

def crear_tabla_memoria():
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS memoria (
                clave TEXT PRIMARY KEY,
                valor TEXT
            )
        ''')
        conn.commit()

def recordar(clave, valor):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("REPLACE INTO memoria (clave, valor) VALUES (?, ?)", (clave, valor))
        conn.commit()

def obtener_recuerdo(clave):
    with conectar() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT valor FROM memoria WHERE clave = ?", (clave,))
        resultado = cursor.fetchone()
        return resultado[0] if resultado else None